
# Classification of Risk level for retail Clients
def classify_retailer(client):
    score = 0

    if client.risk_tolerance:
        score += client.risk_tolerance

    if client.time_horizon:
        if client.time_horizon >= 15:
            score += 5
        elif client.time_horizon >= 7:
            score += 2
        else:
            score += 4
    
    if client.client_goals:
        if client.client_goals == "independence":
            score += 6
        elif client.client_goals == "retirement":
            score += 2
        else:
            score += 1
        
    if client.age:
        if client.age >= 45:
            score += 2
        elif client.age >= 35:
            score += 5
        else:
            score += 7



    # Classification
    if score <= 6:
        return "Conservative"
    elif score <= 12:
        return "Balanced"
    else:
        return "Aggressive"


#
def retail_benchmark_selector(client):
    
    risk = client.risk_profile
    horizon = client.time_horizon
    age = client.age
    goal = client.client_goals

    if risk == "Aggressive":
        
        # Long horizon → high growth tech
        if horizon >= 10:
            return "Nasdaq-100"
        
        # Younger + aggressive → small cap growth
        if age < 35:
            return "Russell 2000"
        
        return "S&P 500"

    elif risk == "Balanced":
        
        # For global diversification
        if goal == "independence":
            return "MSCI World Index"
        
        # Medium horizon → balanced US exposure
        if horizon >= 5:
            return "S&P 500"
        
        return "Dow Jones Industrial Average (DJIA)"

    elif risk == "Conservative":
        
        # Wealth preservation → stable companies
        if goal == "preservation":
            return "Dow Jones Industrial Average (DJIA)"
        
        # Older investors → less volatility
        if age >= 50:
            return "MSCI World Index"
        
        return "S&P 500"

    # fallback
    return "S&P 500"

# Static custom asset location for retail clients based on profile and horizon
def retail_asset_allocation(client):

    risk = client.risk_profile
    horizon = client.time_horizon

    if risk == "Aggressive":
        if horizon >= 10:
            return {
                "Equities": 80,
                "Bonds": 10,
                "Cash": 5,
                "Alternatives": 5
            }
        else:
            return {
                "Equities": 70,
                "Bonds": 15,
                "Cash": 10,
                "Alternatives": 5
            }

    elif risk == "Balanced":
        return {
            "Equities": 60,
            "Bonds": 25,
            "Cash": 10,
            "Alternatives": 5
        }

    else:
        return {
            "Equities": 40,
            "Bonds": 40,
            "Cash": 15,
            "Alternatives": 5
        }
    
